from django.apps import AppConfig


class ApptestConfig(AppConfig):
    name = 'apptest'
