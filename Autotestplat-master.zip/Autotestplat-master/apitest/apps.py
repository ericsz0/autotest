from django.apps import AppConfig


class ApitestConfig(AppConfig):
     name = 'apitest'