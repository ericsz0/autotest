from django.apps import AppConfig


class SetConfig(AppConfig):
    name = 'set'
